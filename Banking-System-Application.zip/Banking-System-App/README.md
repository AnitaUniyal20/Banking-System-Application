 #Banking-System

This app is made to complete Task#2 of Graduate Rotational Intership Program(GRIP) of The Sparks Foundation i.e.,Basic Banking System in an android app.

By using this app,User can see their bank details and can transfer money to other user's. Then, his/her can able see their transactions history.

